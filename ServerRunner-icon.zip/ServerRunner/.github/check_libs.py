"""Keep only libraries that can actually be bundled for Android (Chaquopy, arm64, Python 3.11).
A package is OK if Chaquopy's repo has a cp311 arm64 wheel, or PyPI has a pure-Python (py3-none-any) wheel.
Packages that fail are dropped (with their parents) so the build still succeeds; see libs-report.txt."""
import json, re, urllib.request

REQ = "app/requirements.txt"
CHAQUO = "https://chaquo.com/pypi-13.1/{}/"
# native packages that a library cannot work without
DEPS = {
    "fastapi": ["pydantic"], "pydantic": ["pydantic-core"],
    "argon2-cffi": ["argon2-cffi-bindings"], "cryptography": ["cffi"],
}

def get(url):
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            return r.read().decode("utf-8", "replace")
    except Exception:
        return None

cache = {}
def ok(pkg):
    pkg = re.sub(r"[-_.]+", "-", pkg).lower()
    if pkg in cache:
        return cache[pkg]
    res = (False, "no Android wheel / not pure-Python")
    html = get(CHAQUO.format(pkg))
    if html and re.search(r"cp311[^\"<>]*arm64_v8a", html):
        res = (True, "Chaquopy native wheel")
    else:
        js = get(f"https://pypi.org/pypi/{pkg}/json")
        if js:
            try:
                if any(f["filename"].endswith("-none-any.whl") for f in json.loads(js)["urls"]):
                    res = (True, "pure Python")
            except Exception:
                pass
    cache[pkg] = res
    return res

def check(pkg):
    good, why = ok(pkg)
    if not good:
        return False, why
    for d in DEPS.get(pkg.lower(), []):
        g, w = check(d)
        if not g:
            return False, f"needs {d}: {w}"
    return True, why

keep, report = [], []
for line in open(REQ):
    s = line.strip()
    if not s or s.startswith("#"):
        keep.append(line.rstrip()); continue
    name = re.split(r"[\[<>=!~ ;]", s)[0]
    good, why = check(name)
    if good:
        keep.append(line.rstrip())
    report.append(f"{'INCLUDED' if good else 'DROPPED '}  {name:<16} {why}")

open(REQ, "w").write("\n".join(keep) + "\n")
open("libs-report.txt", "w").write("\n".join(report) + "\n")
print("\n".join(report))
